#ifndef GENERIC
#define GENERIC
#include <stdio.h>
#include <stdlib.h>

#endif