g++ FSM.c -o -g FSM
./FSM input.in