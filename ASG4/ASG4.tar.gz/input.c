int main()
{
int inti=433  ,i= 330,  ans = 330;
    int x= 100;    float pi      =3.145555;for  (i =0  ;i<x; i++ )ans+=4;return ans;}